package com.example.securelogin;

public class JwtUtil {
    public static String generateToken(String username) {
        // Use a JWT library like jjwt or java-jwt
        return "fake-jwt-token-for-" + username;
    }
}